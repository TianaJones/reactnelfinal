export function Guest () {

    return(
        <>
    <header>  Guest Page</header>
    <div>
        Thanks 
        for
        accepting my invite
    </div>
    <div className="front">
            {/* Place your front image here */}
          </div>
          <button>Read only</button>
        </>
    )
}