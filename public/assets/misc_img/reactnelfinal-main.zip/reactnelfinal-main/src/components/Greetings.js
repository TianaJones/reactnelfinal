

// import React, { useState } from 'react';
// import './App.css';
export function Welcome () {

    
return <h1>Hello, Nellie</h1>

// const App = () => {
//   const [isOpen, setIsOpen] = useState(false);

//   const handlecurtainClick = () => {
//     setIsOpen(!isOpen);
//   };

//   const handleNextClick = () => {
//     // Handle navigation to the other side
//   };

//   return (
//     <div className="container">
//       <div className={`curtain ${isOpen ? 'curtain' : ''}`} onClick={handlecurtainClick}>
//         {isOpen ? (
//           <>
//             <div className="text">
//               { <h1> Nellie <br></br>welcome you to her birthday web</h1> }
//             </div>
//             <div className="sparkle"></div>
//           </>
//         ) : (
//           <div className="front">
//             {/* Place your front image here */}
//           </div>
//         )}
//       </div>
//       <div className="scrolling-images">
//         {/* Place your scrolling images here */}
//       </div>
//       <button className="next-button" onClick={handleNextClick}>Next</button>
//     </div>
//   );
// };
}

// // export default App;