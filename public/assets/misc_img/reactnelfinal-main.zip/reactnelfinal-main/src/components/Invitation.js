export function Invitation () {

    return(
        <>
        <div>
     <h1> join us to celebrate </h1>
     <p> Birthday </p>
     

               <label>Name</label>
                <input type="text"/>
                <label>Date</label>
                <input type="text"/>
                 <label>Time</label>
                <input type="number"/>
                <label>Place</label>
                <input type="text"/>

                </div>

                <div>
     <h1>please join us for a surprise</h1>
     <p> Engagement</p>
     <p> Honoring</p>

               <label>Name</label>
                <input type="text"/>
                <label>Date</label>
                <input type="text"/>
                 <label>Time</label>
                <input type="number"/>
                <label>Place</label>
                <input type="text"/>

                </div>


                <div>
     <h1>You are invited to</h1>
     <p> Our Wedding</p>
    

               <label>Name</label>
                <input type="text"/>
                <label>Date</label>
                <input type="text"/>
                 <label>Time</label>
                <input type="number"/>
                <label>Place</label>
                <input type="text"/>

                </div>

                <div>
     <h1>Annievarsary</h1>
     <p> Save the date</p>
     <p> we warmly invite you to our wedding annievarsary</p>

               <label>Name</label>
                <input type="text"/>
                <label>Date</label>
                <input type="text"/>
                 <label>Time</label>
                <input type="number"/>
                <label>Place</label>
                <input type="text"/>

                </div>
        </>
    )
}